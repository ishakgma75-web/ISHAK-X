#!/data/data/com.termux/files/usr/bin/bash
set -e

echo "=== ISHAK X BUILD CHECK ==="

test -f index.html || {
 echo "ERROR: index.html missing"
 exit 1
}

mkdir -p app/src/main/assets
cp index.html app/src/main/assets/index.html

echo "HTML interface: READY"
echo "Project assets: READY"

echo "Next: Android SDK and Gradle build setup required."
